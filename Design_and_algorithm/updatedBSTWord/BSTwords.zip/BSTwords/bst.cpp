#include "bst.h"
#include <QDebug>
BST::BST():left(nullptr),right(nullptr),parent(nullptr),nodeWord(nullptr) {
}

BST::BST(const QString &word, BST* p, BST*l, BST*r):
    left(l),right(r),parent(p) {

    nodeWord = new Word(word);
};

BST::~BST() {
    delete nodeWord;
    delete left;
    delete right;
}

BST* BST::insert(const QString &word) {
    if (nodeWord==nullptr) {
        nodeWord = new Word(word);
    } else if (!(*nodeWord==word)) {
        parent = new BST(word,nullptr,this,nullptr);
        return parent;
    }
    return this;
}

bool BST::search(const QString &src,int &n) {
    n++;
    auto ptr=this;
    while (ptr!=nullptr && !(*(ptr->nodeWord)==src)) {
        ptr=ptr->left;
        n++;
    }
    return (ptr!=nullptr);
}
