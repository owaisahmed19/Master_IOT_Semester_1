//
//  RowMainView.swift
//  ProjectIOS
//
//  Created by devxcode on 17/10/2025.
//

import Foundation

import SwiftUI

struct ItemExpense: View {
    
    let todo: ExpenseModel
    @EnvironmentObject var viewModelExpense : ViewModelExpense

    
    var body: some View {
       
        let deviceColor = viewModelExpense.colorEnum(priority: todo.deviceType)


        HStack{
        
            Text(todo.brand).font(.system(.title2)).bold()
            Spacer()
            VStack{
                HStack{Text("\(todo.cost) € ").font(.system(size: 17))
                    Text(todo.deviceType.rawValue).font(.footnote)
                        .font(.system(size: 13)).padding(5).foregroundStyle(deviceColor).frame(minWidth: 62).overlay(Capsule()
                        .stroke(deviceColor))}
                
                Text(todo.date.formatted(.dateTime.day().month().year())).font(.system(size: 14))

            }
            
            
        }.padding(.vertical,12).padding(.horizontal,3).font(.title2)
    }
}

struct RontentView_Previews: PreviewProvider {
    static var previews: some View {
        ItemExpense(todo: ExpenseModel(brand: "alpkz", cost: 6766, deviceType : .Vacation,date: Date()))
            .environmentObject(ViewModelExpense())
    }
}
