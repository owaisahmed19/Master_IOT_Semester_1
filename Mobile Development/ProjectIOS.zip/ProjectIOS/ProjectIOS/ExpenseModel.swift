//
//  ExpenseModel.swift
//  ProjectIOS
//
//  Created by devxcode on 16/10/2025.
//

import Foundation

enum Priority: String,CaseIterable {
    case All
    case Perso
    case Pro
    case Vacation
}

struct ExpenseModel: Identifiable {
    
    var id=UUID()
    var brand:String
    var cost:Int
    var deviceType:Priority
    let date: Date

    static var expenseData = [
        ExpenseModel(brand:"Apple",cost:9658,deviceType: Priority.Perso,date: Date()),
        ExpenseModel(brand:"Airbnd",cost:120000,deviceType: Priority.Pro,date: Date()),
        ExpenseModel(brand:"Android",cost:2398,deviceType: Priority.Perso,date: Date()),
        ExpenseModel(brand:"Mac OS",cost:78678,deviceType: Priority.Vacation,date: Date()),
    ]
}

