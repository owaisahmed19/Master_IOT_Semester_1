//
//  ContentView.swift
//  ProjectIOS
//
//  Created by devxcode on 16/10/2025.
//

import SwiftUI

import SwiftUI

//struct ContentView: View {
    
   // @State var todoTitle: String = ""
    //@State  var priority: Priority = .pacation
    
    //@EnvironmentObject var viewModelExpense:ViewModelExpense
      
   // @State var todoTitle: String = ""
    //@State  var priority: Priority = .pacation
    
    //@EnvironmentObject var viewModelExpense:ViewModelExpense
    
   // var body: some View {
     //   WindowGroup {
          //  ProjectShowUI()
       // }
    //}
    
//}


/*
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ProjectShowUI()
    }
}
 */

/*

VStack {
    TextField("Enter Your Name", text: $todoTitle)
        .padding(.horizontal)
        .frame(height: 60)
        .background(Color(.systemGray4))
        .cornerRadius(10)
    
    Picker("Priority",selection: $priority){
        ForEach(Priority.allCases,id: \.self){
            Text($0.rawValue)
        }
    }.pickerStyle(SegmentedPickerStyle())
    
    Button{
       // toduViewModel.addTodo(title: todoTitle, priority: //priority)
       // self.presentationMode.wrappedValue.dismiss()
    }label: {
        
        Text("SAVE")
            .font(.headline)
            .frame(height: 55)
            .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
            .background(.blue)
            .foregroundStyle(.white)
            .cornerRadius(18)
        
    }
}.padding(14)

*/
