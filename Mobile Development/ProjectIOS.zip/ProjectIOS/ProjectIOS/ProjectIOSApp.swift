//
//  ProjectIOSApp.swift
//  ProjectIOS
//
//  Created by devxcode on 16/10/2025.
//


import SwiftUI

@main
struct ProjectIOSApp: App {
    @StateObject private var viewModelExpense = ViewModelExpense()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(viewModelExpense)
        }
    }
}

struct MainTabView: View {
    var body: some View {
        TabView {
            ExpenseScreen()
                .tabItem {
                    Image(systemName: "doc.text.fill")
                    Text("Expenses")
                }

            OverViewScreen()
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                    Text("Overview")
                }
        }
    }
}

struct ContentView_Main: PreviewProvider {
    static var previews: some View {
        MainTabView()
            .environmentObject(ViewModelExpense())
    }
}



