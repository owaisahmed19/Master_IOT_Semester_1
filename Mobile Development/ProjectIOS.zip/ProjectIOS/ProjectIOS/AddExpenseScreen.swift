//
//  AddNewExpenseView.swift
//  ProjectIOS
//
//  Created by devxcode on 18/10/2025.
//

import SwiftUI

struct AddExpenseScreen: View {
    
    @Environment(\.dismiss) var dismiss

    @State var titleExpense: String = ""
    @State private var selectedDate = Date()
    @State private var costExpense: String = ""
    @State private var costExpenseValue: Int = 0
    @State  var priority: Priority = .Perso
    @EnvironmentObject var viewModelExpense:ViewModelExpense
    
    @State private var showToast = false

    
    func handlePriorityChange(_ priority: Priority) {
        print("Priority changed to: \(priority.rawValue)")
        
    }
    var body: some View {
            ZStack {
                VStack {
                    TextField("Enter Your Expense", text: $titleExpense)
                        .padding(.horizontal)
                        .frame(height: 55)
                        .background(Color(.systemGray4))
                        .cornerRadius(10)
                        .padding(.top, 3)
                        .padding(.bottom, 3)

                
                        TextField("0", text: $costExpense)
                            .keyboardType(.numberPad)
                            .padding(.horizontal)
                            .frame(height: 55)
                            .background(Color(.systemGray4))
                            .cornerRadius(10)
                            .padding(.top, 3)
                            .padding(.bottom, 3)
                            .onChange(of: costExpense) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    costExpense = filtered
                                }
                            }
                            
                       
                    Picker("Priority", selection: $priority) {
                        ForEach(Priority.allCases.dropFirst(), id: \.self) { priority in
                            Text(priority.rawValue)
                        }
                    }.pickerStyle(SegmentedPickerStyle())
                        .padding(.top, 4)
                        .padding(.bottom, 4)

                    HStack {
                        Text("Select Date").font(.title2).bold()
                        Spacer()

                        DatePicker("", selection: $selectedDate, displayedComponents: .date)
                                           .datePickerStyle(.compact)
                            
                    }.padding(.top,20).padding(.horizontal,15)
                    Spacer()
                    Button{
                        viewModelExpense.addTodo(
                            mBrand: titleExpense,
                            mcost: Int(costExpense) ?? 0,
                            priority: priority,
                            mDate: selectedDate
                        )
                        titleExpense = ""
                        dismiss()

                    }label: {
                        Text("SAVE")
                            .font(.headline)
                            .frame(height: 50)
                            .frame(width: 300)
                            .background(.blue)
                            .foregroundStyle(.white)
                            .cornerRadius(10)
                        
                    }
                    
                }
                
                
            }.padding(14)
            .navigationTitle("Add an Expense")
            .toolbar{
                
                ToolbarItem(placement: .navigationBarTrailing) {
                                  Button(action: {
                                      dismiss()
                                  }) {
                                      Image(systemName: "xmark")
                                  }
                    
                }
    
            }
    
    }
    
}


struct AddNewExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        AddExpenseScreen()
    }
}
