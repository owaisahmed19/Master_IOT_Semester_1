//
//  ProjectShowUI.swift
//  ProjectIOS
//
//  Created by devxcode on 17/10/2025.
//

import SwiftUI

struct ExpenseScreen: View {
    
    @EnvironmentObject var viewModelExpense : ViewModelExpense
    
    @State var todoTitle: String = ""
    @State  var priority: Priority = .All
    
    func handlePriorityChange(_ priority: Priority) {
        print("Priority changed to: \(priority.rawValue)")
    }
    
    var body: some View {
        NavigationView{
            ZStack{
                VStack{
                    Picker("Priority",selection: $priority){
                        ForEach(Priority.allCases,id: \.self){
                            Text($0.rawValue)
                        }
                    }.pickerStyle(SegmentedPickerStyle()).padding(10)
                    .onChange(of: priority) { newValue in
                        handlePriorityChange(newValue)
                    }
                    
                    List{
                        ForEach(viewModelExpense.toduArray.filter { expense in
                            priority == .All || expense.deviceType == priority
                            }) { expense in
                                ItemExpense(todo: expense)
                            }
                    }.listStyle(PlainListStyle())
                        .navigationTitle("Expense")
                        .toolbar{
                            ToolbarItem(placement: .navigationBarLeading){
                                EditButton()
                            }
                            ToolbarItem(placement: .navigationBarTrailing){
                                NavigationLink("Add",destination:
                                AddExpenseScreen())
                            }
                        }
                    
                }
            }
        }
    }
    
    
  
}
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ExpenseScreen()
            .environmentObject(ViewModelExpense())
    }
}
