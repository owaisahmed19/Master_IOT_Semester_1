//
//  ViewModelExpense.swift
//  ProjectIOS
//
//  Created by devxcode on 16/10/2025.
//

import Foundation
import SwiftUI



class ViewModelExpense:ObservableObject {
    
    @Published var toduArray : [ExpenseModel]=[]
    
    init(){
        getTodu()
    }
    
    func getTodu(){
        toduArray.append(contentsOf: ExpenseModel.expenseData)
    }
    
    func colorEnum(priority : Priority) -> Color {
        switch priority {
        case .Perso:
            return .red
        case .Vacation:
            return .orange
        case .Pro:
            return .green
        default:
            return .gray
        }
    }
    

    func addTodo(mBrand:String,mcost:Int, priority:Priority,mDate:Date){
        let newTodo=ExpenseModel(brand: mBrand ,cost: mcost, deviceType:priority,date: mDate)
        toduArray.append(newTodo)
    }
    
}
