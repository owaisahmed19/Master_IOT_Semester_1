//
//  OverViewScreen.swift
//  ProjectIOS
//
//  Created by devxcode on 18/10/2025.
//

import SwiftUI

struct OverViewScreen: View {
    @State  var priority: Priority = .All
    @EnvironmentObject var viewModelExpense : ViewModelExpense

    @State  var costPerso: Int = 0
    @State  var costVacation: Int = 0
    @State  var costPro: Int = 0
    
    @State private var startDate = Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date()
    @State private var endDate = Date()
   

    
    
    private func calculateTotals() {
            let filtered = viewModelExpense.toduArray.filter { expense in
                expense.date >= startDate && expense.date <= endDate
            }
            
            costPerso = 0
            costVacation = 0
            costPro = 0
            
            for expense in filtered {
                switch expense.deviceType {
                case .Perso:
                    costPerso += expense.cost
                case .Vacation:
                    costVacation += expense.cost
                case .Pro:
                    costPro += expense.cost
                case .All:
                    break 
                }
            }
        }
    
    var body: some View {
        
        NavigationView {
            ZStack {
                VStack {
                    HStack {
                        Text("Period start date").font(.title2).bold()
                        Spacer()

                        DatePicker("", selection: $startDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                            
                    }.padding(.bottom,10)
                    HStack {
                        Text("Period end date").font(.title2).bold()
                        Spacer()
                        DatePicker("", selection: $endDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                        
                    }
                    Rectangle()
                        .frame(height: 2)
                        .foregroundColor(Color(.systemGray2)).padding(.horizontal,13).padding(.top,15)
                    Spacer()
                    HStack {
                        Text("Perso").padding(5).foregroundStyle(.red).frame(height: 40).frame(width: 120).overlay(Capsule()
                            .stroke(.red)).font(.title2).bold()
                        Spacer()
                        Text( "\(costPerso) €").font(.title2).bold()
                    }
            
                    HStack{
                        Text("Vacation").padding(5).foregroundStyle(.orange).frame(width: 120).frame(height: 40).overlay(Capsule()
                            .stroke(.orange)).font(.title2).bold()
                        Spacer()
                        Text( "\(costVacation) €").font(.title2).bold()

                    }.padding(.vertical,20)
                    HStack{
                        Text("Pro").padding(5).foregroundStyle(.green).frame(height: 40).frame(width: 120).overlay(Capsule()
                            .stroke(.green)).font(.title2).bold()
                        Spacer()
                        Text( "\(costPro) €").font(.title2).bold()
                    }
                    Spacer()
                    Rectangle()
                        .frame(height: 2)
                        .foregroundColor(Color(.systemGray2)).padding(.horizontal,20).padding(.bottom,10)
                    
                    Text( "Total: \(costPerso+costVacation+costPro)").font(.title).bold()
                }.padding(15)
                .onChange(of: startDate) { _ in calculateTotals() }
                .onChange(of: endDate) { _ in calculateTotals() }
                .onAppear { calculateTotals() }
                .onAppear { calculateTotals()}
               
                Text("")
                    .navigationTitle("Overview")
            }
            
        }
    }

}

struct OverViewScreen_Previews: PreviewProvider {
    static var previews: some View {
        OverViewScreen()
    }
}
